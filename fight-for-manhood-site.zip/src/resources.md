    ---
    title: "Resources"
    description: "Short tools and downloads to support your growth."
    layout: "base.njk"
    permalink: "/resources/"
    ---
    # Resources

This page will grow over time.

## Quick tools
- **Weekly review**: What did I do? What did I avoid? What will I do next?
- **Integrity check**: Where am I hiding? Where am I rationalizing?

## Downloads
Coming soon:
- Program overview PDF
- 12-week tracker
- Discussion guides
