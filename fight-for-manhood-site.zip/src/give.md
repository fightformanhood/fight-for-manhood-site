    ---
    title: "Give"
    description: "Support the mission of Fight for Manhood."
    layout: "base.njk"
    permalink: "/give/"
    ---
    # Give

This movement grows when men step up.

**Coming soon:** a secure giving link and a clear budget story (venue, materials, scholarships, outreach).

If you want to give now, contact us:
- Go to **Contact** and send “I want to give.”
