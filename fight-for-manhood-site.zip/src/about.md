    ---
    title: "About"
    description: "The mission, tone, and vision behind Fight for Manhood."
    layout: "base.njk"
    permalink: "/about/"
    ---
    # About

Fight for Manhood exists to call men out of passivity and into responsible strength.

This isn’t a lecture series. It’s a proving ground.

## Our mission
To build men who:
- **Lead with integrity**
- **Love their families with strength and tenderness**
- **Work with excellence**
- **Walk with God without hiding**

## Our tone
We push hard — because the stakes are high.

But we don’t crush men. We train them.

## Our conviction
“When a man steps into the light without shame, everything changes.”
