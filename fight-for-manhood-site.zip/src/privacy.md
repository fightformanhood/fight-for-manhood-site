    ---
    title: "Privacy"
    description: "Our privacy promise in plain language."
    layout: "base.njk"
    permalink: "/privacy/"
    ---
    # Privacy

We keep it simple:
- We don’t sell your info.
- We only use contact details to communicate about Fight for Manhood.
- If you want your data removed, contact us and we will remove it.

(We can expand this into a formal policy once the organization is set up legally.)
