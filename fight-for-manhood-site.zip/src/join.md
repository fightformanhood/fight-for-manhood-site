    ---
    title: "Join"
    description: "RSVP / apply to join Fight for Manhood."
    layout: "base.njk"
    permalink: "/join/"
    ---
    # Join the next class

**This is the fastest way to get in.**

For now, this page is intentionally simple. We can turn it into a real application form once you pick the tool (Google Form, Typeform, Jotform, etc.).

## What to send (copy/paste)
- Name:
- Phone:
- Email:
- Age:
- Why you want to join:
- How you heard about us:

Send it to: **info@fightformanhood.org** (placeholder)

<div class="rule"></div>

## If you’re a graduate / founding crew
Include: “FOUNDING CREW” in your message.
