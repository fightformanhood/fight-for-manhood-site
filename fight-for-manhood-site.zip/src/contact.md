    ---
    title: "Contact"
    description: "Get in touch with Fight for Manhood."
    layout: "base.njk"
    permalink: "/contact/"
    ---
    # Contact

Email: **info@fightformanhood.org** (placeholder)

If you want, we can wire this page to a simple contact form (Netlify Forms, Formspree, etc.).

**Best message to send:**
- Your name
- Your phone number (optional)
- Why you want to join
