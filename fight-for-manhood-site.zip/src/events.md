    ---
    title: "Events"
    description: "Upcoming Fight for Manhood meetings and gatherings."
    layout: "base.njk"
    permalink: "/events/"
    ---
    # Events

## Next class
**Start:** First Wednesday of March 2026 (**March 4, 2026**)  
**Time:** 6:30–8:30 PM (typical)  
**Cost:** Free

> If you’re reading this after March 4, 2026, we’ll post the next start date here.

## Interest nights
If we host an interest night, it will be listed here.

<div class="cta-row">
  <a class="btn btn-primary" href="/join/">RSVP / Apply</a>
  <a class="btn" href="/contact/">Ask about dates</a>
</div>
